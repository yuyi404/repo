#!/usr/bin/env fish

# IPA 注入脚本 - 支持多文件选择、多 DYLIB 选择、可选 Bundle ID，
# 以及为每个 Bundle ID（含原版）单独指定图标和 APP 名称

# ####################
# 配置文件区域（按需修改）
# ####################

set ipa_dir         "/var/mobile/Documents/injectipa/ipa"      # IPA 目录路径
set dylib_dir       "/var/mobile/Documents/injectipa/dylib1"   # DYLIB 目录
set resource_dir    "/var/mobile/Documents/injectipa/资源文件/" # 资源文件路径
set image_dir       "/var/mobile/Documents/injectipa/图标/"     # 图标路径
set name_dir        "测试1" "测试2"                             # APP 名称列表
set bundle_ids      "com.tencent.qy.xin" "com.tencent.wx" "com.tencent.xin1"      # Bundle ID 列表
# ####################
# 初始化设置
# ####################


sudo chown -R mobile:mobile "$dylib_dir"


# 安全获取 IPA 文件（排除系统文件）
set ipa_files
for file in $ipa_dir/*.ipa
    if not string match -q "*DS_Store*" -- $file
        set -a ipa_files $file
    end
end
if test (count $ipa_files) -eq 0
    echo (set_color red)"错误：在 $ipa_dir 目录中未找到任何 IPA 文件！"(set_color normal)
    exit 1
end
# 获取当前日期（格式 mm-dd-HH-MM）
set current_date (date "+%m-%d-%H-%M")
# 获取并检查 dylib 文件
set dylib_files
for file in $dylib_dir/*.dylib
    set -a dylib_files $file
end
if test (count $dylib_files) -eq 0
    echo (set_color red)"错误：在 $dylib_dir 中未找到任何 dylib 文件！"(set_color normal)
    exit 1
end
# ####################
# 函数定义
# ####################
# 列表展示
function show_list
    set -l title $argv[1]
    set -l items $argv[2..-1]
    echo (set_color yellow)"\n$title："(set_color normal)
    for i in (seq 1 (count $items))
        set filename (basename "$items[$i]")
        printf "  %2s. %-40s\n" (set_color blue)"$i"(set_color normal) "$filename"
    end
end
# 调用 injectipa 的封装，新增 icon 和 name 参数
function run_inject -a bundle_id ipa_path output_name resource_files icon name
    echo "正在处理: "(basename "$ipa_path")" → $output_name.ipa"
    set cmd_args \
        "$ipa_path" \
        $selected_dylibs\
        -s \
        -o "$output_name"

    if test -n "$resource_files"
        set -a cmd_args -a $resource_files
    end
    if test -n "$bundle_id"
        set -a cmd_args -b "$bundle_id"
    else
        set -a cmd_args -p
    end
    if test -n "$icon"
        set -a cmd_args -i "$icon"
    end
    if test -n "$name"
        set -a cmd_args -n "$name"
    end
    if not sudo -u mobile injectipa $cmd_args -w
        echo (set_color red)"错误: 处理 $cmd_args 失败！"(set_color normal)
        exit 1
    end
    echo "成功生成: "(set_color green)"$output_name.ipa"(set_color normal)
end
# 输入校验
function validate_input -a max
    while true
        read -P "请输入选择 (0-$max，多个用逗号分隔): " choice
        set choice (string trim -- "$choice")
        set selections (string split "," -- $choice | string trim)
        if test -z "$choice"
            echo "错误：输入不能为空！"
            continue
        end
        set valid true
        set nums
        for n in $selections
            if not string match -qr '^[0-9]+$' -- $n
                echo "错误：'$n' 不是数字！"
                set valid false; break
            end
            if test $n -lt 0 -o $n -gt $max
                echo "错误：选项 $n 超出范围！"
                set valid false; break
            end
            set -a nums $n
        end
        if $valid
            set -g user_choices (printf "%s\n" $nums | sort -nu)
            return 0
        end
    end
end
# ####################
# 主程序逻辑
# ####################
# 1. 选择 IPA
show_list "请选择要处理的 IPA 文件" $ipa_files
echo "  "(set_color cyan)"0. 处理全部文件"(set_color normal)
validate_input (count $ipa_files)
set choices $user_choices
if contains 0 $choices
    set selected_files $ipa_files
else
    set selected_files
    for idx in $choices
        set -a selected_files $ipa_files[$idx]
    end
end
# 2. 选择 DYLIB
show_list "请选择要注入的 DYLIB 文件" $dylib_files
echo "  "(set_color cyan)"0. 注入全部 DYLIB"(set_color normal)
validate_input (count $dylib_files)
set dylib_choices $user_choices
if contains 0 $dylib_choices
    set -g selected_dylibs $dylib_files
else
    set -g selected_dylibs
    for idx in $dylib_choices
        set -a selected_dylibs $dylib_files[$idx]
    end
end
# 3. 选择资源文件（可选）
# 第三步：选择单一资源文件
echo (set_color yellow)"\n是否添加资源文件？(1=是 / 0=否)"(set_color normal)
read -l add_resources
if test "$add_resources" = "1"
    # 枚举资源文件
    set resource_items
    for file in $resource_dir/*
        set -a resource_items $file
    end
    if test (count $resource_items) -eq 0
        echo (set_color red)"错误：在 $resource_dir 中未找到任何资源文件！"(set_color normal)
        exit 1
    end
    # 列表展示
    show_list "请选择要添加的资源文件（仅限单选）" $resource_items
    set max_res (count $resource_items)
    # 单选输入验证
    while true
        read -P "请输入单一选择 (1-$max_res，输入序号即可): " res_choice
        set res_choice (string trim -- "$res_choice")
        if string match -qr '^[0-9]+$' -- $res_choice
            set num (math "$res_choice")
            if test $num -ge 1 -a $num -le $max_res
                set resource_files $resource_items[$num]
                break
            end
        end
        echo "错误：请输入有效的单一选项！"
    end
end
# 4. 选择 Bundle ID 方案
echo (set_color yellow)"\n请选择打包方案："(set_color normal)
echo "  "(set_color blue)"0."(set_color normal)" 全部 Bundle ID + 原版"
echo "  "(set_color blue)"1."(set_color normal)" 不修改 Bundle ID（官替）"
for i in (seq 1 (count $bundle_ids))
    set idx (math $i + 1)
    echo "  "(set_color blue)"$idx."(set_color normal)" 使用："(set_color cyan)"$bundle_ids[$i]"(set_color normal)
end
set max_opt (math (count $bundle_ids) + 1)
validate_input $max_opt
set bundle_choice $user_choices
# 冲突校验：禁止 “0” 与其他同选
if contains 0 $bundle_choice; and test (count $bundle_choice) -gt 1
    echo (set_color red)"错误：不能同时选择‘全部 Bundle ID’和其他选项！"(set_color normal)
    exit 1
end
# 构建目标 ID 列表（含空串表示原版）
set target_ids
for n in $bundle_choice
    if test $n -eq 0
        # 全部：先加所有 IDs，再加原版
        for bid in $bundle_ids
            set -a target_ids $bid
        end
        set -a target_ids ""
        break
    else if test $n -eq 1
        # 原版
        set -a target_ids ""
    else
        # 具体 ID
        set -a target_ids $bundle_ids[(math $n - 1)]
    end
end
# 5. 为每个 target ID 单独询问图标和名称
set icons_map; set names_map
for bid in $target_ids
    if test -n "$bid"
        set label (string split "." -- $bid | awk 'NR==3{print tolower($0)}')
    else
        set label "官替"
    end
    echo "\n"(set_color yellow)"是否为 [$label] 单独修改图标和 APP 名称？(1=是/0=否)"(set_color normal)
    read -l modify
    if test "$modify" = "1"
        # 图标
        set icon_items
        for f in $image_dir/*; set -a icon_items $f; end
        show_list "请选择图标" $icon_items
        validate_input (count $icon_items)
        set sel_icon $icon_items[$user_choices[1]]
        # 名称
        show_list "请选择应用名称" $name_dir
        validate_input (count $name_dir)
        set sel_name $name_dir[$user_choices[1]]
    else
        set sel_icon ""; set sel_name ""
    end
    set -a icons_map $sel_icon
    set -a names_map $sel_name
end
# 6. 执行注入
echo "\n"(set_color yellow)"======== 开始处理 ========"(set_color normal)
for ipa in $selected_files
    set base (basename "$ipa" .ipa)
    for idx in (seq 1 (count $target_ids))
        set bid      $target_ids[$idx]
        set icon     $icons_map[$idx]
        set app_name $names_map[$idx]
        if test -n "$bid"
            set short_id (string split "." -- $bid | awk 'NR==3{print tolower($0)}')
            set out_name "$base"_"$short_id"多开_"$current_date"
        else
            set out_name "$base"_官替_"$current_date"
        end
        run_inject "$bid" "$ipa" "$out_name" $resource_files "$icon" "$app_name"
    end
end
echo (set_color green)"\n======== 全部任务完成 ========"(set_color normal)