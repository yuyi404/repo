#!/usr/bin/env fish
# IPA 注入脚本 - 支持多文件选择、多 DYLIB 选择、可选 Bundle ID

# ####################
# 配置文件区域（按需修改）
# ####################

set ipa_dir     "/var/mobile/Documents/injectipa/ipa"    # IPA 目录路径
set dylib_dir   "/var/mobile/Documents/injectipa/dylib"  # DYLIB 目录

set resource_dir  "/var/mobile/Documents/injectipa/组件/BHInstaLocalization.bundle"   #资源文件路径


set image_file  "/var/mobile/Documents/injectipa/ipa/IMG_1605.png" # 图标路径
set bundle_ids  "com.tencent.qy.xin" "com.tencent.mm.xin"

# ####################
# 初始化设置
# ####################

# 安全获取 IPA 文件（排除系统文件）
set ipa_files
for file in $ipa_dir/*.ipa
    if not string match -q "*DS_Store*" -- $file
        set -a ipa_files $file
    end
end

if test (count $ipa_files) -eq 0
    echo (set_color red)"错误：在 $ipa_dir 目录中未找到任何 IPA 文件！"(set_color normal)
    exit 1
end

# 获取当前日期（月-日格式）
set current_date (date "+%m-%d")

# 获取并检查 dylib 文件
set dylib_files
for file in $dylib_dir/*.dylib
    set -a dylib_files $file
end

if test (count $dylib_files) -eq 0
    echo (set_color red)"错误：在 $dylib_dir 中未找到任何 dylib 文件！"(set_color normal)
    exit 1
end

# ####################
# 函数定义
# ####################

function show_list
    set -l title $argv[1]
    set -l items $argv[2..-1]

    echo (set_color yellow)"\n$title："(set_color normal)
    for i in (seq 1 (count $items))
        set filename (basename "$items[$i]")
        printf "  %2s. %-40s\n" (set_color blue)"$i"(set_color normal) "$filename"
    end
end

function run_inject -a bundle_id ipa_path output_name 
    echo "正在处理: "(basename "$ipa_path")" → $output_name.ipa"
    
    set cmd_args \
        "$ipa_path" \
        $selected_dylibs \
         -s \
        -o "$output_name" \

    if test -n "$bundle_id"
        set -a cmd_args -b "$bundle_id"
    else 
        set -a cmd_args -p
    end

    if not sudo -u mobile injectipa $cmd_args -a $resource_dir
        echo (set_color red)"错误: 处理 $output_name 失败！"(set_color normal)
        exit 1
    end
    
    echo "成功生成: "(set_color green)"$output_name.ipa"(set_color normal)
end

function validate_input -a max
    while true
        read -P "请输入选择 (0-$max，多个用逗号分隔): " choice
        set choice (string trim -- "$choice")
        set choices (string split "," -- $choice | string trim)

        if test -z "$choice"
            echo "错误：输入不能为空！"
            continue
        end

        set valid true
        set selected_index
        for num in $choices
            if not string match -qr '^[0-9]+$' -- $num
                echo "错误：'$num' 不是数字！"
                set valid false
                break
            end
            
            set num (math "$num" + 0)
            if test $num -lt 0 -o $num -gt $max
                echo "错误：选项 $num 超出范围！"
                set valid false
                break
            end
            
            set -a selected_index $num
        end

        if $valid
            # 去重并排序
            set -g user_choices (printf "%s\n" $selected_index | sort -nu)
            return 0
        end
    end
end

# ####################
# 主程序逻辑
# ####################

# 第一步：选择 IPA 文件
show_list "请选择要处理的 IPA 文件" $ipa_files
echo "  "(set_color cyan)"0. 处理全部文件"(set_color normal)

validate_input (count $ipa_files)
set choices $user_choices

if contains 0 in $choices
    set selected_files $ipa_files
else
    set selected_files
    for i in $choices
        set -a selected_files $ipa_files[$i]
    end
end

# 第二步：选择 DYLIB 文件
show_list "请选择要注入的 DYLIB 文件" $dylib_files
echo "  "(set_color cyan)"0. 注入全部 DYLIB"(set_color normal)

validate_input (count $dylib_files)
set dylib_choices $user_choices

if contains 0 in $dylib_choices
    set -g selected_dylibs $dylib_files
else
    set -g selected_dylibs
    for i in $dylib_choices
        set -a selected_dylibs $dylib_files[$i]
    end
end

# 第三步：选择 Bundle ID
echo (set_color yellow)"\n请选择打包方案："(set_color normal)
echo "  "(set_color blue)"0."(set_color normal)" 全部 Bundle ID + 原版"
echo "  "(set_color blue)"1."(set_color normal)" 不修改 Bundle ID（官替）"
for i in (seq 1 (count $bundle_ids))
    set idx (math $i + 1)
    echo "  "(set_color blue)"$idx."(set_color normal)" 使用："(set_color cyan)"$bundle_ids[$i]"(set_color normal)
end

set max_option (math (count $bundle_ids) + 1)
validate_input $max_option
set bundle_choice $user_choices

# 检查选项冲突
if contains 0 $bundle_choice; and test (count $bundle_choice) -gt 1
    echo (set_color red)"错误：不能同时选择全部 Bundle ID 和其他选项！"(set_color normal)
    exit 1
else if contains 1 $bundle_choice; and test (count $bundle_choice) -gt 1
    echo (set_color red)"错误：不能同时选择不修改 Bundle ID 和其他选项！"(set_color normal)
    exit 1
end

# 处理组合逻辑
echo "\n"(set_color yellow)"======== 开始处理 ========"(set_color normal)
for ipa in $selected_files
    set output_base (basename "$ipa" _dump.ipa)余忆
    set suffix (random 10000 99999)
    
    # 处理全部 Bundle ID + 原版
    if contains 0 in $bundle_choice
        # 处理所有配置的 Bundle ID
        for bid in $bundle_ids
            set short_id (string split "." -- "$bid" | awk 'NR==3 {print tolower($0)}')
            set output_name "$output_base"_"$short_id"_"$current_date"-"$suffix"
            run_inject "$bid" "$ipa" "$output_name"
        end
        # 额外生成原版（不修改 Bundle ID）
        set output_name "$output_base"_官替_"$current_date"-"$suffix"
        run_inject "" "$ipa" "$output_name"
    # 不修改 Bundle ID（官替）
    else if contains 1 in $bundle_choice
        set output_name "$output_base"_官替_"$current_date"-"$suffix"
        run_inject "" "$ipa" "$output_name"
    # 处理单个/多个 Bundle ID
    else
        for choice in $bundle_choice
            if test $choice -ge 2
                set bid $bundle_ids[(math $choice - 1)]
                set short_id (string split "." -- "$bid" | awk 'NR==3 {print tolower($0)}')
                set output_name "$output_base"_"$short_id"_"$current_date"-"$suffix"
                run_inject "$bid" "$ipa" "$output_name"
            end
        end
    end
end

echo (set_color yellow)"======== 处理完成 ========"(set_color normal)