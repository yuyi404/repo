

if (typeof imagecount === 'undefined') { var imagecount = 4; }
if (typeof duration === 'undefined') { var duration = 3000; }
if (typeof animation === 'undefined') { var animation = 'fade'; }

var count = 0;
var updt = function () {
    $('#ss>img').eq(count % imagecount).toggleClass('show');
    $('#ss>img').eq((count - 1) % imagecount).removeClass('show');
    count++;
};
setInterval(updt, duration);

$(function () {
    for (var i = 0; i < imagecount; i++) {
        var fileName = i + '.jpg';
        if (i < 10) { fileName = '0' + fileName; }
        $('#ss').append($('<img>', { src: fileName }));
    }
    $('#ss').addClass(animation);
    updt();
})
